
-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(191) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`, `comment`) VALUES
(1, 'Рейтинг западных сериалов', ''),
(2, 'Рейтинг японских дорам', ''),
(3, 'Рейтинг российских сериалов', ''),
(4, 'Рейтинг корейских дорам', ''),
(5, 'Рейтинг полнометражных фильмов', '');
